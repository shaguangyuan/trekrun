"""
AI Report Analyzer: DeepSeek-powered secondary analysis for sprint video results.

Provides:
- Layered formal report (data quality first, then metrics, cross-analysis, limitations)
- Parsed structured report_json for optional frontend use
- Risk flagging without medical diagnosis

Output: Structured JSON saved to uploads/<video_id>_ai_analysis.json
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from app.config import settings
from app.services.ai.ai_input_builder import build_ai_input, build_user_prompt
from app.services.ai.deepseek_client import DeepSeekError, get_client, is_configured

logger = logging.getLogger(__name__)

PROMPT_VERSION = "v2.0"

# Schema hint for the model (soft contract; parsing still tolerates minor omissions).
AI_OUTPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "report_title": {"type": "string"},
        "report_text": {
            "type": "string",
            "description": "Full formal report in Chinese with numbered sections 1-8 as specified in system prompt",
        },
        "report_json": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "data_quality": {"type": "object"},
                "metric_analysis": {"type": "array"},
                "cross_metric_findings": {"type": "array"},
                "major_issues": {"type": "array"},
                "confidence": {"type": "object"},
                "limitations": {"type": "array"},
                "verification_and_acceptance": {"type": "object"},
            },
        },
        "ai_summary": {
            "type": "string",
            "description": "3-5 sentences executive summary in Chinese (analysis credibility, top findings, anomalies)",
        },
        "evidence_trace": {"type": "array", "items": {"type": "string"}},
        "key_findings": {"type": "array"},
        "metric_interpretations": {"type": "array"},
        "risk_flags": {"type": "array"},
        "limitations": {"type": "array", "items": {"type": "string"}},
        "suggestions": {"type": "array", "items": {"type": "string"}},
        "confidence_statement": {"type": "string"},
        "recommended_next_steps": {"type": "array", "items": {"type": "string"}},
    },
    "required": [
        "report_title",
        "report_text",
        "report_json",
        "ai_summary",
        "evidence_trace",
        "key_findings",
        "risk_flags",
        "limitations",
        "confidence_statement",
    ],
}

SYSTEM_PROMPT = """你是运动生物力学与短跑技术分析报告撰写助手。你只能依据用户给出的结构化输入（四层 JSON 摘要）进行推理，不得编造未提供的数值或事件。

## 写作顺序（强制执行）

1) 先做数据质量与异常检查：pose 覆盖、关键点可见性/稳定性、插值与抖动 proxy、踝事件检测置信度（由输入中的 QC 与 anomaly_checks 推断）、步频是否极端异常、指标间是否矛盾。
2) 若数据不足以支撑强结论，必须在报告最前面明确写「不建议强解释」，并列出需要复核的指标与原因。
3) 再逐项解释核心指标（每项：定义、当前值/表现、可能含义、可信度、是否易受视频质量影响）。
4) 再做交叉指标分析：哪些互相支持、哪些矛盾、哪些更可能来自算法/数据而非真实动作。
5) 识别异常与矛盾：生理不合理、重复计数嫌疑、抖动污染等，区分 data issue vs technique。
6) 最后：主要问题排序（数据问题优先于动作解释）、结论与限制。

## 输出语气

- 正式技术分析报告，不要聊天口吻，不要空泛鼓励，不要模板套话。
- 禁止伤病诊断与医疗建议；仅训练与技术观察、复核建议。
- stance/swing、contact/flight proxy、gait cycle、foot progression 等在输入中若标注为 proxy/启发式，你必须说明并非测力台真值。

## report_text 结构（必须按此编号与标题输出完整长文）

1. 报告标题（单行，可与 report_title 一致）
2. 分析摘要（3-5 句）
3. 数据质量评估
4. 核心指标逐项分析（至少包含：cadence；left/right symmetry；contact/flight timing（若仅有 proxy 须写明）；hip/knee/ankle 相关；trunk lean；pelvic drop（若无数据写「输入未提供 pelvic drop，不可用臆测」）；foot strike / overstride 相关 proxy）
5. 交叉指标综合分析
6. 主要问题排序（3-5 条，数据质量问题排前）
7. 结论与限制
8. 验收与复核建议（对应 report_json.verification_and_acceptance）

## 必须输出的单一 JSON 对象（顶层字段）

整个回复只能是合法 JSON，不要 markdown 代码围栏，不要 JSON 外的文字。

顶层字段必须包含：
- report_title: 字符串
- report_text: 字符串（含以上 1-8 节完整正文）
- report_json: 对象，键至少包含：
  - summary: 字符串（与摘要一致或略压缩）
  - data_quality: 对象（video/landmark/stability/events 等分项结论）
  - metric_analysis: 数组，对象字段至少 name, current_value_or_state, interpretation, credibility, caveats
  - cross_metric_findings: 数组（支持/矛盾/可能同源模式/更像算法误差）
  - major_issues: 数组，对象字段至少 priority, category(data_quality|technique|algorithm), description
  - confidence: 对象，含 overall, interpretability_level(strong|moderate|weak), per_metric_notes
  - limitations: 字符串数组
  - verification_and_acceptance: 对象，含 how_to_verify, acceptance_criteria 字符串数组
- ai_summary: 字符串（3-5 句执行摘要）
- evidence_trace: 字符串数组（引用输入中的具体字段名与数值）
- key_findings: 数组，对象含 title, description, related_metrics, confidence(high|medium|low)
- metric_interpretations: 数组（可与 metric_analysis 互补，勿空洞）
- risk_flags: 数组，对象含 type(data_quality|technique|symmetry|temporal|algorithm|consistency), message
- limitations: 字符串数组
- suggestions: 字符串数组（训练与拍摄改进，非医疗）
- confidence_statement: 字符串
- recommended_next_steps: 字符串数组

当 layer_3_quality_control.data_quality_anomaly_checks 中任一项 out_of_range==true 或 severity 为 high，或 data_quality_grade 为 low/insufficient，你必须在摘要与 major_issues 首位强调数据限制，不得假装一切正常。"""


def _pose_coverage_from_rfs(rfs: Dict[str, Any]) -> float:
    """Normalize pose coverage from raw_feature_summary (pose_ratio / computed ratio)."""
    explicit = rfs.get("pose_coverage")
    if explicit is not None and float(explicit) > 0:
        return float(explicit)
    total = int(rfs.get("total_frames") or 0)
    if total <= 0:
        return 0.0
    detected = float(rfs.get("pose_detected_frames") or 0)
    return detected / float(total)


def _normalize_ai_result(ai_result: Dict[str, Any]) -> Dict[str, Any]:
    """Ensure new fields exist for backward compatibility and API consumers."""
    rj = ai_result.get("report_json")
    if not isinstance(rj, dict):
        rj = {
            "summary": str(ai_result.get("ai_summary") or ""),
            "data_quality": {},
            "metric_analysis": list(ai_result.get("metric_interpretations") or []),
            "cross_metric_findings": [],
            "major_issues": [],
            "confidence": {"overall": "unknown", "interpretability_level": "weak"},
            "limitations": list(ai_result.get("limitations") or []),
            "verification_and_acceptance": {
                "how_to_verify": "重新侧向录制、全身入镜、稳定机位与光线；对比多次上传。",
                "acceptance_criteria": [
                    "pose_coverage 与下肢关键点 valid ratio 达到可解释阈值",
                    "步频与左右节律在片段内自洽",
                    "无严重抖动/插值导致的相位漂移",
                ],
            },
        }
        ai_result["report_json"] = rj
    if not ai_result.get("report_title"):
        ai_result["report_title"] = "跑步动作分析报告"
    if not ai_result.get("report_text"):
        ai_result["report_text"] = str(ai_result.get("ai_summary") or "")
    return ai_result


def run_ai_analysis(
    video_id: str,
    feature_groups: Optional[Dict[str, Any]] = None,
    raw_feature_summary: Optional[Dict[str, Any]] = None,
    analysis_overview: Optional[Dict[str, Any]] = None,
    natural_language: Optional[Dict[str, Any]] = None,
    metric_confidence: Optional[Dict[str, float]] = None,
    used_frames: Optional[Dict[str, int]] = None,
    used_joints: Optional[Dict[str, List[str]]] = None,
    metrics_available: Optional[List[str]] = None,
    warnings: Optional[List[str]] = None,
    suggested_fix: Optional[str] = None,
    analysis_state: str = "done",
    force_refresh: bool = False,
) -> Dict[str, Any]:
    """
    Run AI analysis on sprint video data using DeepSeek.

    Args:
        video_id: Video identifier
        feature_groups: Feature groups from feature_extractor
        raw_feature_summary: Raw feature summary
        analysis_overview: Analysis overview dict
        natural_language: Natural language explanation
        metric_confidence: Per-metric confidence scores
        used_frames: Per-metric used frame counts
        used_joints: Per-metric used joints
        metrics_available: List of successfully computed metrics
        warnings: Warning messages
        suggested_fix: Suggested fix message
        analysis_state: Overall analysis state
        force_refresh: If True, regenerate even if cache exists

    Returns:
        AI analysis result dict
    """
    cache_path = _ai_analysis_path(video_id)
    if not force_refresh and os.path.exists(cache_path):
        logger.info("AI analysis cache hit for video_id=%s", video_id)
        with open(cache_path, encoding="utf-8") as fh:
            cached = json.load(fh)
            return _normalize_ai_result(cached)

    if not is_configured():
        logger.warning("DeepSeek not configured, returning fallback analysis for video_id=%s", video_id)
        return _build_fallback_analysis(
            video_id=video_id,
            analysis_state=analysis_state,
            warnings=warnings,
            data_quality=_estimate_data_quality(raw_feature_summary, metric_confidence, metrics_available),
        )

    ai_input = build_ai_input(
        video_id=video_id,
        feature_groups=feature_groups,
        raw_feature_summary=raw_feature_summary,
        analysis_overview=analysis_overview,
        natural_language=natural_language,
        metric_confidence=metric_confidence,
        used_frames=used_frames,
        used_joints=used_joints,
        metrics_available=metrics_available,
        warnings=warnings,
        suggested_fix=suggested_fix,
        analysis_state=analysis_state,
    )

    user_prompt = build_user_prompt(ai_input)
    client = get_client()
    try:
        logger.info("Calling DeepSeek for video_id=%s", video_id)
        ai_result = client.generate_structured(
            system_prompt=SYSTEM_PROMPT,
            user_prompt=user_prompt,
            json_schema_hint=AI_OUTPUT_SCHEMA,
            temperature=0.25,
        )
        ai_result = _normalize_ai_result(ai_result)

        ai_result["_metadata"] = {
            "video_id": video_id,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "model_name": client.model,
            "prompt_version": PROMPT_VERSION,
            "data_quality_grade": ai_input.get("layer_3_quality_control", {}).get("data_quality_grade"),
        }

        _save_ai_analysis(video_id, ai_result)
        logger.info("AI analysis completed and saved for video_id=%s", video_id)

        return ai_result

    except DeepSeekError as exc:
        logger.error("DeepSeek error for video_id=%s: %s", video_id, exc)
        return _build_fallback_analysis(
            video_id=video_id,
            analysis_state=analysis_state,
            warnings=warnings,
            data_quality=_estimate_data_quality(raw_feature_summary, metric_confidence, metrics_available),
            error_message=str(exc),
        )
    except Exception as exc:
        logger.exception("Unexpected error during AI analysis for video_id=%s", video_id)
        return _build_fallback_analysis(
            video_id=video_id,
            analysis_state=analysis_state,
            warnings=warnings,
            data_quality=_estimate_data_quality(raw_feature_summary, metric_confidence, metrics_available),
            error_message=f"Analysis error: {exc}",
        )


def read_ai_analysis(video_id: str) -> Optional[Dict[str, Any]]:
    """Read cached AI analysis for video_id."""
    path = _ai_analysis_path(video_id)
    if not os.path.exists(path):
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            return _normalize_ai_result(json.load(fh))
    except Exception:
        return None


def _ai_analysis_path(video_id: str) -> str:
    return os.path.join(settings.upload_dir, f"{video_id}_ai_analysis.json")


def _save_ai_analysis(video_id: str, data: Dict[str, Any]) -> None:
    os.makedirs(settings.upload_dir, exist_ok=True)
    path = _ai_analysis_path(video_id)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def _estimate_data_quality(
    raw_feature_summary: Optional[Dict[str, Any]],
    metric_confidence: Optional[Dict[str, float]],
    metrics_available: Optional[List[str]],
) -> str:
    """Estimate overall data quality grade."""
    rfs = dict(raw_feature_summary or {})
    pose_coverage = _pose_coverage_from_rfs(rfs)
    core_valid = float(rfs.get("core_joint_valid_ratio") or 0)
    metrics_count = len(metrics_available or [])

    if pose_coverage >= 0.8 and core_valid >= 0.7 and metrics_count >= 5:
        return "high"
    elif pose_coverage >= 0.5 and core_valid >= 0.5 and metrics_count >= 3:
        return "medium"
    elif pose_coverage >= 0.3 and metrics_count >= 1:
        return "low"
    return "insufficient"


def _build_fallback_analysis(
    video_id: str,
    analysis_state: str,
    warnings: Optional[List[str]] = None,
    data_quality: str = "unknown",
    error_message: Optional[str] = None,
) -> Dict[str, Any]:
    """Build fallback analysis when DeepSeek is unavailable or fails."""
    is_partial = analysis_state == "partial"
    is_failed = analysis_state == "failed"
    warns = list(warnings or [])

    if is_failed:
        summary = (
            "本次视频分析未能完成，无法生成基于指标的可靠分层报告。"
            " 在流程未成功产出有效片段与数值前，不建议对动作强弱做解释。"
        )
        evidence = [
            "分析流程未完成：缺少与指标计算绑定的有效连续片段或必要字段。",
            "无法区分数据缺失、检测失败与真实动作表现。",
        ]
        findings: List[Dict[str, Any]] = []
        risk_flags = [
            {"type": "data_quality", "message": "分析未完成：无法评估技术动作，请先修复拍摄或解码问题后重试。"}
        ]
        strong_warn = "不建议强解释：分析未成功完成。"
    elif is_partial:
        summary = (
            "本次仅部分指标可用，分层报告仅能基于已提供字段做保守描述；"
            " 结论的不确定性高于完整分析，需谨慎引用。"
        )
        evidence = [
            "部分指标成功计算，其余缺失或置信度受限。",
            "解读应优先标注数据缺口，而不是推断未经验证的跑动模式。",
        ]
        findings = [
            {
                "title": "部分指标可用",
                "description": "可用子集可能无法代表全程技术稳定状态。",
                "related_metrics": [],
                "confidence": "low",
            }
        ]
        risk_flags = [{"type": "data_quality", "message": "部分指标数据质量或可用性不足，技术结论仅限弱解释。"}]
        strong_warn = "不建议强解释：指标未完整覆盖五项核心输出。"
    else:
        summary = (
            "本次流水线已完成指标计算，但当前环境未启用大模型二次解读；"
            " 以下为结构化占位报告，便于接口联调；启用 API 后将替换为完整推理文本。"
        )
        evidence = [
            "基于 MediaPipe 派生特征与 QC 摘要的占位输出（非 LLM 生成）。",
            f"数据质量等级（启发式）：{data_quality}。",
        ]
        findings = [
            {
                "title": "分析完成（占位解读）",
                "description": "指标已落盘；深层交叉推理需配置 DeepSeek 后生成。",
                "related_metrics": [],
                "confidence": "medium",
            }
        ]
        risk_flags = []
        strong_warn = "" if data_quality in ("high", "medium") else "不建议强解释：数据质量等级偏低。"

    limitations = [
        "单目侧向视频不能替代实验室动作捕捉；若干时空量为算法 proxy。",
        "占位报告不包含模型驱动的交叉验证与矛盾检测全文。",
    ]
    if data_quality in ("low", "insufficient"):
        limitations.append("本次数据质量有限，任何动作层面的结论均应降级为假设。")

    report_title = "跑步动作分析报告（离线/占位）" if is_failed or error_message else "跑步动作分析报告"

    report_text_sections = "\n\n".join(
        [
            f"1. {report_title}",
            f"2. 分析摘要\n{summary}",
            (
                "3. 数据质量评估\n"
                f"- 启发式等级：{data_quality}。\n"
                "- 未完成分析时：无法评估 landmark 稳定性或事件检测可靠性。\n"
                f"- 上游告警：{warns if warns else '无额外告警记录'}。"
            ),
            (
                "4. 核心指标逐项分析\n"
                "当前为 fallback：未调用 LLM，无法根据实算 cadence / 对称性 / 关节角等逐项展开；"
                " 启用 DeepSeek 后将按输入 JSON 完整展开。"
            ),
            "5. 交叉指标综合分析\n占位：需完整指标与模型输出。",
            f"6. 主要问题排序\n1) {strong_warn or '按数据质量—算法—技术顺序复核'}\n2) 若仍失败，检查侧向全身入镜与有效片段时长。",
            "7. 结论与限制\n" + limitations[0],
            "8. 验收与复核建议\n- 侧向、全身、稳定机位与光线；多次采集对比趋势。",
        ]
    )

    report_json: Dict[str, Any] = {
        "summary": summary,
        "data_quality": {
            "grade_heuristic": data_quality,
            "strong_interpretation_ok": data_quality in ("high", "medium") and not is_failed and not is_partial,
            "notes": evidence,
            "warnings": warns,
        },
        "metric_analysis": [],
        "cross_metric_findings": [],
        "major_issues": (
            [{"priority": 1, "category": "data_quality", "description": "分析流程未完成或占位解读。"}]
            if is_failed
            else [{"priority": 1, "category": "data_quality", "description": strong_warn or "按优先完成数据侧复核"}]
        ),
        "confidence": {
            "overall": "low" if is_failed or is_partial else "medium",
            "interpretability_level": "weak" if is_failed or is_partial else "moderate",
            "per_metric_notes": "fallback：无模型分项注释",
        },
        "limitations": limitations,
        "verification_and_acceptance": {
            "how_to_verify": "重新上传侧向标准片段；确认 job 状态为 done 且 metrics 五项齐全后再请求 AI。",
            "acceptance_criteria": [
                "分析状态 success 且 core 指标五项非占位零值（按业务定义）",
                "pose_coverage 与下肢关键点 valid ratio 达到项目阈值",
                "无持续的 QC 失败与 metric warning 未处理",
            ],
        },
    }

    result: Dict[str, Any] = {
        "report_title": report_title,
        "report_text": report_text_sections,
        "report_json": report_json,
        "ai_summary": summary,
        "evidence_trace": evidence,
        "key_findings": findings,
        "metric_interpretations": [],
        "risk_flags": risk_flags,
        "limitations": limitations,
        "suggestions": [
            "保持侧面全身入镜与稳定机位，光线充足。",
            "完成一次标准片段后可重复采集用于趋势对比。",
        ],
        "confidence_statement": (
            f"本次为离线占位/错误回退输出，基于{data_quality}启发式质量估计；"
            " 不构成实验结论，仅用于流程与接口占位。"
        ),
        "recommended_next_steps": [
            "配置 DEEPSEEK_API_KEY 后刷新 AI 解读。",
            "若持续失败，检查上传视频与 QC 告警文本。",
        ],
        "_metadata": {
            "video_id": video_id,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "model_name": "fallback",
            "prompt_version": PROMPT_VERSION,
            "data_quality_grade": data_quality,
            "is_fallback": True,
            "error": error_message,
        },
    }

    _save_ai_analysis(video_id, result)
    return result
